import { combineReducers } from "redux";
import login from "./login"
import navleft from "./navleft"

let reducer = combineReducers({
    login, navleft
})
export default reducer