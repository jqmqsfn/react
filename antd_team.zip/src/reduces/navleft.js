let navleft = (state = { collapsed: false, initialPane: {} }, action) => {
    switch (action.type) {
        case "NAV_TOGGLE":
            return { collapsed: action.collapsed }
        case "NAV_TAG":
            return { initialPane: action.initialPane }
        default:
            return state
    }
}
export default navleft