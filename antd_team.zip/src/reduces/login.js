function login(state = {
    data: { aname: "", apass: "" },
    loading: true
}, action) {
    switch (action.type) {
        case "LOGIN":
            return {
                loading: false,
                data: action.data
            }
        default: return state
    }
}
export default login