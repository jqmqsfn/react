import React, { Component } from "react"
import { Switch } from "react-router-dom"
// import Welcome from "../views/Welcome"
// import Otherpage from "../views/OtherPage"
// import Classification from "../views/Classification"
// import Login from "../views/Login"

class RouterIndex extends Component {
    render() {
        return (
            <Switch>
                {/* <Route path="/index/login" component={Login} />
                <Route path="/index/welcome" component={Welcome} />
                <Route path="/index/otherpage" component={Otherpage} />
                <Route path="/index/class" component={Classification} />
                <Route path="/" render={
                    () => {
                        return <Redirect to="/index" />
                    }
                } /> */}
            </Switch>
        )
    }
}
export default RouterIndex