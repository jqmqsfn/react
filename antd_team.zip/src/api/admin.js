import myajax from "./myajax"
export const adminlogin = (admin) => myajax("admin/login", admin, "post")
export const adminlist = () => myajax("admin/list")