

export const mytime = () => {
    const d1 = new Date()
    let Y = d1.getFullYear()
    let M = d1.getMonth() + 1 < 10 ? "0" + Number(d1.getMonth() + 1) : d1.getMonth() + 1
    let D = d1.getDate() < 10 ? "0" + d1.getDate() : d1.getDate()
    let h = d1.getHours()
    let m = d1.getMinutes() < 10 ? "0" + d1.getMinutes() : d1.getMinutes()
    let s = d1.getSeconds() < 10 ? "0" + d1.getSeconds() : d1.getSeconds()
    return `${Y}/${M}/${D} ${h}:${m}:${s}`
}