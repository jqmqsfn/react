//存储
function setCookies(name, value, exdays) {
    var d = new Date()
    d.setTime(d.getTime() + exdays * 24 * 60 * 60 * 1000)
    document.cookie = name + "=" + value + ";expires=" + d
}

//获取
function getCookies(myName) {
    var name = myName + "=";
    var info = document.cookie.split(";")
    for (var i = 0; i < info.length; i++) {
        var c = info[i].trim();
        if (c.indexOf(name) === 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

//删除
function delCookies(myName) {
    setCookies(myName, "", -1)
}

export { setCookies, delCookies, getCookies }