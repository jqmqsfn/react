import React, { Component } from "react";
import { Menu, Layout } from "antd";
import { connect } from "react-redux";
import {
  AppstoreOutlined,
  UserOutlined,
  FileProtectOutlined,
  ApartmentOutlined,
} from "@ant-design/icons";
import "../css/mainnav.css";
const { Sider } = Layout;
const { SubMenu } = Menu;
class MainNav111 extends Component {
  constructor() {
    super();
    this.state = {
      result: [
        {
          path: 1,
          title: "会员管理",
          icon: <UserOutlined />,
          subs: [
            { path: 11, title: "统计页面" },
            { path: 12, title: "会员列表(静态表格)" },
            { path: 13, title: "会员列表(动态表格)" },
            { path: 14, title: "会员管理" },
            { path: 15, title: "等级管理" },
          ],
        },
        {
          path: 2,
          title: "订单管理",
          icon: <FileProtectOutlined />,
          subs: [
            { path: 21, title: "订单列表" },
            { path: 22, title: "订单列表1" },
          ],
        },
        {
          path: 3,
          title: "分类管理",
          icon: <FileProtectOutlined />,
          subs: [{ path: 31, title: "多级分类" }],
        },
        {
          path: 4,
          title: "城市联动",
          icon: <FileProtectOutlined />,
          subs: [{ path: 41, title: "三级地区联动" }],
        },
        {
          path: 5,
          title: "管理员管理",
          icon: <UserOutlined />,
          subs: [
            { path: 51, title: "管理员列表" },
            { path: 52, title: "角色管理" },
            { path: 53, title: "权限分类" },
            { path: 54, title: "权限管理" },
          ],
        },
        {
          path: 6,
          title: "系统统计",
          icon: <ApartmentOutlined />,
          subs: [
            { path: 61, title: "折线图" },
            { path: 62, title: "柱状图" },
            { path: 63, title: "地图" },
            { path: 64, title: "饼图" },
            { path: 65, title: "雷达图" },
            { path: 66, title: "k线图" },
            { path: 67, title: "热力图" },
            { path: 68, title: "仪表图" },
          ],
        },
        {
          path: 7,
          title: "图标字体",
          icon: <AppstoreOutlined />,
          subs: [{ path: 71, title: "图标对应字体" }],
        },
        {
          path: 8,
          title: "其他页面",
          icon: <AppstoreOutlined />,
          subs: [
            { path: 81, title: "登陆页面" },
            { path: 82, title: "错误页面" },
          ],
        },
        {
          path: 9,
          title: "layui第三方组件",
          icon: <AppstoreOutlined />,
          subs: [
            { path: 91, title: "滑块验证" },
            { path: 92, title: "富文本编辑器" },
            { path: 93, title: "eleTree 树组件" },
            { path: 94, title: "图片截取" },
            { path: 95, title: "formSelects 4.x 多选框" },
            { path: 96, title: "Magnifier 放大镜" },
            { path: 97, title: "notice 通知控件" },
          ],
        },
      ],
    };
  }
  getMenu = (menuList) => {
    return menuList.map((item) => {
      if (!item.subs) {
        return (
          <Menu.Item key={item.path} icon={item.icon}>
            <div>
              <span>{item.title}</span>
            </div>
          </Menu.Item>
        );
      } else {
        return (
          <SubMenu key={item.path} title={item.title} icon={item.icon}>
            {this.getMenu(item.subs)}
          </SubMenu>
        );
      }
    });
  };
  componentWillMount() {
    this.menuDataList = this.getMenu(this.state.result);
  }
  render() {
    return (
      <Sider collapsed={this.props.collapsed}>
        <Menu style={{ height: "100%" }} mode="inline">
          {this.menuDataList}
        </Menu>
      </Sider>
    );
  }
}

export default connect((state) => state.navleft)(MainNav111);
