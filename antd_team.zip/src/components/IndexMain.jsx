import React, { Component } from "react";
// import RouterIndex from "../router";
import { Layout, Tabs } from "antd";
import Welcome from "../views/Welcome";
import MainNav from "./MainNav";
import { HomeOutlined } from "@ant-design/icons";

// eslint-disable-next-line
import Login from "../views/Login";
// eslint-disable-next-line
import ErrorPage from "../views/ErrorPage";

import "../css/indexmain.css";
import { connect } from "react-redux";
// eslint-disable-next-line
const { Sider, Content } = Layout;
const { TabPane } = Tabs;
const initialPanes = [
  {
    title: (
      <span>
        <HomeOutlined />
        我的桌面
      </span>
    ),
    content: <Welcome />,
    key: "1",
    closable: false,
  },
];
class IndexMain extends Component {
  constructor() {
    super();
    this.state = {
      activeKey: initialPanes[0].key,
      panes: initialPanes,
    };
    this.newTabIndex = 0;
  }
  onChange = (activeKey) => {
    this.setState({ activeKey });
  };
  onEdit = (targetKey, action) => {
    this[action](targetKey);
  };
  add = () => {
    const { panes } = this.state;
    const activeKey = `newTab${this.newTabIndex++}`;
    const newPanes = [...panes];
    newPanes.push({
      title: "New Tab",
      content: "Content of new Tab",
      key: activeKey,
    });
    this.setState({
      panes: newPanes,
      activeKey,
    });
  };
  remove = (targetKey) => {
    const { panes, activeKey } = this.state;
    let newActiveKey = activeKey;
    let lastIndex;
    panes.forEach((pane, i) => {
      if (pane.key === targetKey) {
        lastIndex = i - 1;
      }
    });
    const newPanes = panes.filter((pane) => pane.key !== targetKey);
    if (newPanes.length && newActiveKey === targetKey) {
      if (lastIndex >= 0) {
        newActiveKey = newPanes[lastIndex].key;
      } else {
        newActiveKey = newPanes[0].key;
      }
    }
    this.setState({
      panes: newPanes,
      activeKey: newActiveKey,
    });
  };
  componentWillReceiveProps() {
    this.getTag();
  }
  getTag() {
    console.log(this.props.initialPane);
    const { panes } = this.state;
    const activeKey = `newTab${this.newTabIndex++}`;
    const newPanes = [...panes];
    if (!newPanes.some((item) => item.key === this.props.initialPane.key)) {
      newPanes.push(this.props.initialPane);
    }
    this.setState({
      panes: newPanes,
      activeKey,
    });
  }
  render() {
    const { panes, activeKey } = this.state;
    return (
      <Layout style={{ height: "95vh" }}>
        <MainNav />
        <Content style={{ overflowY: "scroll" }}>
          <Tabs
            type="editable-card"
            onChange={this.onChange}
            activeKey={activeKey}
            onEdit={this.onEdit}
            size="small"
          >
            {panes.map((pane) => (
              <TabPane tab={pane.title} key={pane.key} closable={pane.closable}>
                {pane.content}
              </TabPane>
            ))}
          </Tabs>
        </Content>
      </Layout>
    );
  }
}
export default connect((state) => state.navleft)(IndexMain);
