import React, { Component } from "react";
import { Layout, Row, Col, Menu, Dropdown, Modal, message, Button } from "antd";
import { CaretDownOutlined, CaretUpOutlined } from "@ant-design/icons";
import "../css/index.css";
import { delCookies } from "../utils/myCookie";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import { MenuUnfoldOutlined, MenuFoldOutlined } from "@ant-design/icons";

class IndexHeader extends Component {
  constructor(props) {
    super(props);
    this.state = {
      flag: true,
      borderColor: "#001529",
      admin: props.admin,
      flag2: true,
      borderColor2: "#001529",
    };
  }
  toggleCollapsed = () => {
    this.props.dispatch({
      type: "NAV_TOGGLE",
      collapsed: !this.props.collapsed,
    });
  };
  render() {
    const menu = (
      <Menu>
        <Menu.Item key="1">
          <a rel="noopener noreferrer" href="/" className="u-menui-word">
            弹出最大化
          </a>
        </Menu.Item>
        <Menu.Item key="2">
          <a rel="noopener noreferrer" href="/" className="u-menui-word">
            弹出自动宽高
          </a>
        </Menu.Item>
        <Menu.Item key="3">
          <a rel="noopener noreferrer" href="/" className="u-menui-word">
            弹出指定宽高
          </a>
        </Menu.Item>
        <Menu.Item key="4">
          <a rel="noopener noreferrer" href="/" className="u-menui-word">
            在tab打开
          </a>
        </Menu.Item>
        <Menu.Item key="5">
          <a rel="noopener noreferrer" href="/" className="u-menui-word">
            在tab打开刷新
          </a>
        </Menu.Item>
      </Menu>
    );
    const menu2 = (
      <Menu>
        <Menu.Item key="11">
          <a rel="noopener noreferrer" href="/" className="u-menui-word">
            个人信息
          </a>
        </Menu.Item>
        <Menu.Item key="12">
          <Link to="/login" className="u-menui-word">
            切换账号
          </Link>
        </Menu.Item>
        <Menu.Item
          key="13"
          onClick={() => {
            Modal.confirm({
              content: "确定退出么？",
              onOk: () => {
                message.info("退出成功");
                delCookies("antd");
              },
            });
          }}
        >
          <Link to="/login" className="u-menui-word">
            退出
          </Link>
        </Menu.Item>
      </Menu>
    );
    return (
      <Layout.Header theme="dark">
        <Row>
          <Col md={4} className="u-index-title">
            <Link to="/index" className="u-index-title-word">
              X-admin v2.2
            </Link>
          </Col>
          <Col md={1} style={{ height: "40px", lineHeight: "40px" }}>
            <Button
              onClick={this.toggleCollapsed}
              style={{
                textAlign: "center",
                background: "#001529",
                color: "#fff",
              }}
              size="small"
            >
              {React.createElement(
                this.props.collapsed ? MenuUnfoldOutlined : MenuFoldOutlined
              )}
            </Button>
          </Col>
          <Col className="m-dropdown-a" md={1}>
            <Dropdown
              overlay={menu}
              onVisibleChange={(e) => {
                this.setState({
                  flag: !this.state.flag,
                });
                if (this.state.flag) {
                  this.setState({
                    borderColor: "#001529",
                  });
                } else {
                  this.setState({
                    borderColor: "#5fb878",
                  });
                }
              }}
            >
              <div
                className="ant-dropdown-link"
                onClick={(e) => e.preventDefault()}
                style={{ borderBottom: "3px solid" + this.state.borderColor }}
              >
                +新增
                {this.state.flag ? <CaretDownOutlined /> : <CaretUpOutlined />}
              </div>
            </Dropdown>
          </Col>
          <Col md={15} style={{ height: "40px" }}></Col>

          <Col className="u-head-admin" md={1}>
            <Dropdown
              overlay={menu2}
              onVisibleChange={() => {
                this.setState({
                  flag2: !this.state.flag2,
                });
                if (this.state.flag2) {
                  this.setState({
                    borderColor2: "#001529",
                  });
                } else {
                  this.setState({
                    borderColor2: "#5fb878",
                  });
                }
              }}
            >
              <div
                className="ant-dropdown-link"
                onClick={(e) => e.preventDefault()}
                style={{ borderBottom: "3px solid" + this.state.borderColor2 }}
              >
                {this.state.admin}
                {this.state.flag2 ? <CaretDownOutlined /> : <CaretUpOutlined />}
              </div>
            </Dropdown>
          </Col>
          <Col md={2} className="u-front-index" style={{ height: "40px" }}>
            <Link to="/" className="u-front-index-a">
              前台首页
            </Link>
          </Col>
        </Row>
      </Layout.Header>
    );
  }
}

export default connect((state) => state.navleft)(IndexHeader);
