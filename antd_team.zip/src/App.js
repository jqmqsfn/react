import "./App.css"
import React, { Component } from "react"
import Index from "./views/Index";
import { Switch, Route, Redirect } from "react-router-dom"
import Login from "./views/Login";

class App extends Component {
    render() {
        return (
            <div>
                <Switch>
                    <Route path="/login" component={Login} />
                    <Route path="/index" component={Index} />
                    <Route path="/" render={
                        () => {
                            return <Redirect to="/index" />
                        }
                    } />
                </Switch>
            </div>
        );
    }
}


export default App;
