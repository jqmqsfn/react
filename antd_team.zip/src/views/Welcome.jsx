import { Card, Col, Row, Table } from "antd";
import React, { Component } from "react";
import { mytime } from "../utils/myinfo";
import { getCookies } from "../utils/myCookie";
import { SmileOutlined } from "@ant-design/icons";

import "../css/welcome.css";
class Welcome extends Component {
  constructor() {
    super();
    this.state = {
      currentTime: mytime(),
      currentUser: null,
      columns: [
        { title: "Information", dataIndex: "name", key: "name" },
        { title: "Version ", dataIndex: "descp", key: "descp" },
      ],
      info: [
        { name: "xxx版本", descp: "1.0.180420", key: 1 },
        { name: "服务器地址", descp: "x.xuebingsi.com", key: 2 },
        { name: "操作系统", descp: "WINNT", key: 3 },
        {
          name: "运行环境",
          descp: "Apache/2.4.23 (Win32) OpenSSL/1.0.2j mod_fcgid/2.3.9",
          key: 4,
        },
        { name: "PHP版本", descp: "5.6.27", key: 5 },
        { name: "PHP运行方式", descp: "cgi-fcgi", key: 6 },
        { name: "MYSQL版本", descp: "5.5.53", key: 7 },
        { name: "ThinkPHP", descp: "5.0.18", key: 8 },
        { name: "上传附件限制", descp: "2M", key: 9 },
        { name: "执行时间限制", descp: "30s", key: 10 },
        { name: "剩余空间", descp: "86015.2M", key: 11 },
      ],
      columns2: [
        { title: "Information", dataIndex: "name", key: "name" },
        { title: "Detail ", dataIndex: "descp", key: "descp" },
      ],
      info2: [
        { name: "版权所有", descp: "xuebingsi(xuebingsi) 访问官网", key: 12 },
        { name: "开发者", descp: "马志斌(113664000@qq.com)", key: 13 },
      ],
    };
  }
  getMytime() {
    this.timeId = setInterval(() => {
      const currentTime = mytime();
      this.setState({
        currentTime,
      });
    }, 1000);
  }
  componentDidMount() {
    this.getMytime();
    this.setState({
      currentUser: JSON.parse(getCookies("antd")).aname,
    });
  }
  componentWillUnmount() {
    clearInterval(this.timeId);
  }
  render() {
    const gridStyle = {
      width: "16%",
      flex: "1",
    };
    return (
      <Row className="g-welcome">
        <Col md={24} className="m-welcome-title">
          <div>
            <span className="u-weltitle-word">欢迎管理员：</span>
            <span className="u-weltitle-word" style={{ color: "red" }}>
              {this.state.currentUser}
            </span>
            <span className="u-weltitle-word">！当前时间：</span>
            <span className="u-weltitle-word">{this.state.currentTime}</span>
          </div>
        </Col>
        <Col md={24} className="m-welcome-card">
          <Card title="数据统计">
            <Card.Grid style={gridStyle}>
              <div style={{ color: "#999999", fontSize: "10px" }}>文章数</div>
              <div style={{ color: "#009688", fontSize: "16px" }}>66</div>
            </Card.Grid>
            <Card.Grid style={gridStyle}>
              <div style={{ color: "#999999", fontSize: "10px" }}>会员数</div>
              <div style={{ color: "#009688", fontSize: "16px" }}>12</div>
            </Card.Grid>
            <Card.Grid style={gridStyle}>
              <div style={{ color: "#999999", fontSize: "10px" }}>回复数</div>
              <div style={{ color: "#009688", fontSize: "16px" }}>99</div>
            </Card.Grid>
            <Card.Grid style={gridStyle}>
              <div style={{ color: "#999999", fontSize: "10px" }}>商品数</div>
              <div style={{ color: "#009688", fontSize: "16px" }}>67</div>
            </Card.Grid>
            <Card.Grid style={gridStyle}>
              <div style={{ color: "#999999", fontSize: "10px" }}>文章数</div>
              <div style={{ color: "#009688", fontSize: "16px" }}>67</div>
            </Card.Grid>
            <Card.Grid style={gridStyle}>
              <div style={{ color: "#999999", fontSize: "10px" }}>文章数</div>
              <div style={{ color: "#009688", fontSize: "16px" }}>6766</div>
            </Card.Grid>
          </Card>
        </Col>
        <Col md={24} className="m-welcome-download">
          <Card
            title={
              <div style={{ fontSize: "12px" }}>
                下载&nbsp;
                <span style={{ color: "#fff", background: "#2F4056" }}>
                  &nbsp;月&nbsp;
                </span>
              </div>
            }
          >
            <div style={{ fontSize: "10px" }}>33,555</div>
            <div style={{ fontSize: "10px" }}>
              新下载 10%
              <SmileOutlined />
            </div>
          </Card>
          <Card
            title={
              <div style={{ fontSize: "12px" }}>
                下载&nbsp;
                <span style={{ color: "#fff", background: "#2F4056" }}>
                  &nbsp;月&nbsp;
                </span>
              </div>
            }
          >
            <div style={{ fontSize: "10px" }}>33,555</div>
            <div style={{ fontSize: "10px" }}>
              新下载 10%
              <SmileOutlined />
            </div>
          </Card>{" "}
          <Card
            title={
              <div style={{ fontSize: "12px" }}>
                下载&nbsp;
                <span style={{ color: "#fff", background: "#2F4056" }}>
                  &nbsp;月&nbsp;
                </span>
              </div>
            }
          >
            <div style={{ fontSize: "10px" }}>33,555</div>
            <div style={{ fontSize: "10px" }}>
              新下载 10%
              <SmileOutlined />
            </div>
          </Card>{" "}
          <Card
            title={
              <div style={{ fontSize: "12px" }}>
                下载&nbsp;
                <span style={{ color: "#fff", background: "#2F4056" }}>
                  &nbsp;月&nbsp;
                </span>
              </div>
            }
          >
            <div style={{ fontSize: "10px" }}>33,555</div>
            <div style={{ fontSize: "10px" }}>
              新下载 10%
              <SmileOutlined />
            </div>
          </Card>
        </Col>
        <Col md={24} className="m-welcome-table">
          <Card title={<span style={{ fontSize: "12px" }}>系统信息</span>}>
            <Table
              dataSource={this.state.info}
              columns={this.state.columns}
              pagination={false}
              bordered
            ></Table>
          </Card>
        </Col>
        <Col md={24} className="m-welcome-team">
          <Card title={<div style={{ fontSize: "12px" }}>开发团队</div>}>
            <Table
              dataSource={this.state.info2}
              columns={this.state.columns2}
              pagination={false}
              bordered
            ></Table>
          </Card>
        </Col>
        <Col md={24} className="m-welcome-footer">
          <div>感谢layui,百度Echarts,jquery,本系统由x-admin提供技术支持。</div>
        </Col>
      </Row>
    );
  }
}

export default Welcome;
