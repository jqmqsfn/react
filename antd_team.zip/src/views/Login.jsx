import React, { Component } from "react";
import { Form, Input, Button, Checkbox, Row, Col, message } from "antd";
import { adminlogin } from "../api/admin.js";
import { connect } from "react-redux";
import "../css/login.css";
import { setCookies } from "../utils/myCookie";

class Login extends Component {
  componentWillMount() {
    // console.log(this.props);
  }
  onFinish = (values) => {
    this.props.dispatch(async (dispatch) => {
      let admin = {
        aname: values.adminname,
        apass: values.password,
      };
      const result = await adminlogin(admin);
      dispatch({
        type: "LOGIN",
        data: result.data,
      });
      if (result.errorNo === 0) {
        message.info(result.msg);
        setCookies("antd", JSON.stringify(result.data), 7);
        this.props.history.replace("/index");
      } else {
        message.error(result.msg + "，用户名或密码错误");
      }
    });
  };
  onFinishFailed(errorInfo) {
    console.log("Failed:", errorInfo);
  }
  render() {
    return (
      <div className="g-login">
        <Row style={{ marginBottom: "40px" }}>
          <Col span={8}></Col>
          <Col span={7} className="m-title">
            <span className="u-titleword">x-admin2.0-管理登录</span>
            <img
              src={require("../imgs/login/aiwrap.png").default}
              alt=""
              className="u-black"
            />
          </Col>
          <Col span={9}></Col>
        </Row>
        <Form
          name="basic"
          labelCol={{ span: 9 }}
          wrapperCol={{ span: 6 }}
          initialValues={{ remember: true }}
          onFinish={this.onFinish}
          onFinishFailed={this.onFinishFailed}
        >
          <Form.Item
            label="用户"
            name="adminname"
            rules={[{ required: true, message: "Please input your username!" }]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            label="密码"
            name="password"
            rules={[{ required: true, message: "Please input your password!" }]}
          >
            <Input.Password />
          </Form.Item>

          <Form.Item
            name="remember"
            valuePropName="checked"
            wrapperCol={{ offset: 9, span: 15 }}
          >
            <Checkbox>Remember me</Checkbox>
          </Form.Item>

          <Form.Item wrapperCol={{ offset: 9, span: 6 }}>
            <Button
              type="primary"
              htmlType="submit"
              style={{ width: "100%", background: "#189f92", height: "40px" }}
            >
              登录
            </Button>
          </Form.Item>
        </Form>
      </div>
    );
  }
}
export default connect((state) => state.login)(Login);
