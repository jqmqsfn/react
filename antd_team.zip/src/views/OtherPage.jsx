import React, { Component } from "react";
class Otherpage extends Component {
  render() {
    return <div>Otherpage</div>;
  }
}

export default Otherpage;
