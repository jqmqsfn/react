import React, { Component } from "react";
import IndexHeader from "../components/IndexHeader";
import { getCookies } from "../utils/myCookie";
import { message } from "antd";
import IndexMain from "../components/IndexMain";
import Login from "./Login";
// import RouterIndex from "../router";
// import Login from "./Login";
class Index extends Component {
  constructor() {
    super();
    this.state = {
      admin: "",
    };
  }
  componentWillMount() {
    if (getCookies("antd")) {
      this.setState({
        admin: JSON.parse(getCookies("antd")).aname,
      });
    } else {
      message.error("请先登录");
      this.props.history.replace("/login");
    }
  }
  render() {
    const url = this.props.match.url;
    return (
      <div>
        {url !== "/login" ? (
          <div>
            <IndexHeader admin={this.state.admin} />
            <IndexMain />
          </div>
        ) : (
          <div className="main">
            <Login />
          </div>
        )}
      </div>
    );
  }
}

export default Index;
