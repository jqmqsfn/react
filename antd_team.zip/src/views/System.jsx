import React, { Component } from 'react';
export default class System extends Component {
    constructor() {
        super();
        this.state = {
        
        }
    }
    render() {
        return (
            <div>
                system
            </div>
        )
    }

}