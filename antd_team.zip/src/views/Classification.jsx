import React, { Component } from "react";
class Classification extends Component {
  render() {
    return <div>classification</div>;
  }
}

export default Classification;
