import React, { Component } from "react";
class ErrorPage extends Component {
  render() {
    return (
      <div style={{ width: "100%", height: "97vh" }}>
        <img
          src={require("../imgs/login/404.png").default}
          alt=""
          style={{ width: "100%", height: "100%" }}
        />
      </div>
    );
  }
}

export default ErrorPage;
