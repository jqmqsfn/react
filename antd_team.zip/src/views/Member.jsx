import React, { Component } from "react";
class Member extends Component {
  render() {
    return (
      <div><p>Member</p></div>
    )
  }


}


export default Member;
