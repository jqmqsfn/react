import Mock from "mockjs"
const loginData = Mock.mock({
    "userData": [
        {
            id: 1,
            aname: "admin",
            apass: "123"
        },
        {
            id: 2,
            aname: "user1",
            apass: "123"
        },
        {
            id: 3,
            aname: "user2",
            apass: "123"
        }

    ]
})
Mock.mock("admin/login", "post", (option) => {
    const user = JSON.parse(option.body);
    for (let i = 0; i < loginData.userData.length; i++) {
        if (loginData.userData[i].aname === user.aname && loginData.userData[i].apass === user.apass) {
            return {
                msg: "登录成功", errorNo: 0, data: loginData.userData[i]
            }
        } else {
            return {
                msg: "登录失败", errorNo: -1
            }

        }
    }
})
Mock.mock("admin/list", loginData);