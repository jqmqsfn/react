import Myajax from "./myajax_base"
const myajax = Myajax
export default myajax