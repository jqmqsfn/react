import myajax from "./myajax"
export const login = (user) => myajax("myuser/login", user, "post")