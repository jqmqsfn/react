import myajax from "./myajax"
export const list = (tab) => myajax(`myinfo/list?tab=${tab}&page=1&limit=22`)
export const queryone = (id) => myajax(`myinfo/one?id=${id}`)
export const userone = (id) => myajax(`myuser/getone?id=${id}`)