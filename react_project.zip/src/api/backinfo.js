import myajax from "./myajax_mock";
export const list = () => myajax('http://localhost:3000/backinfo/list')