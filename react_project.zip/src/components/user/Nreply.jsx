import React, { Component } from "react";
import { List, Avatar } from "antd";
// import { Link } from "react-router-dom";
export default class Nreply extends Component {
  render() {
    return (
      <List
        loading={this.props.loading}
        dataSource={this.props.data}
        renderItem={(item) => (
          <List.Item>
            <List.Item.Meta
              avatar={
                <Avatar src="https://zos.alipayobjects.com/rmsportal/ODTLcjxAfvqbxHnVXCYX.png" />
              }
              title={
                <div>
                  <span style={{ marginLeft: "20px" }}>{item.title}</span>
                  <span style={{ float: "right" }}>
                    最后的回复时间：{item.replydate.split("T")[0]}
                  </span>
                </div>
              }
              description={<div>{item.reply_content}</div>}
            />
          </List.Item>
        )}
      ></List>
    );
  }
}
