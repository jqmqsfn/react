import React, { Component } from "react";
import { List, Avatar } from "antd";
// import { Link } from "react-router-dom";
export default class Near extends Component {
  render() {
    return (
      <List
        loading={this.props.loading}
        dataSource={this.props.data}
        renderItem={(item) => (
          <List.Item>
            <List.Item.Meta
              avatar={
                <Avatar src="https://zos.alipayobjects.com/rmsportal/ODTLcjxAfvqbxHnVXCYX.png" />
              }
              title={
                <div>
                  <span style={{ color: "#4CAEFF" }}>{item.loginname}</span>
                  <span style={{ marginLeft: "20px", color: "#4CAEFF" }}>
                    {item.title}
                  </span>
                  <span style={{ float: "right" }}>
                    最后的发布时间：{item.createdate.split("T")[0]}
                  </span>
                </div>
              }
            />
          </List.Item>
        )}
      ></List>
    );
  }
}
