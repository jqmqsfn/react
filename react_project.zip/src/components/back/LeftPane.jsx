import React, { Component } from "react";
import { Menu, Layout } from "antd";
import { connect } from "react-redux";

import MenuList from "../../datas/menu";
import { Link } from "react-router-dom";
const { Sider } = Layout;
const { SubMenu } = Menu;
class LeftPane extends Component {
  getMenu = (menuList) => {
    return menuList.map((item) => {
      if (!item.children) {
        return (
          <Menu.Item key={item.key} icon={item.icon}>
            <Link to={item.key}>
              <span>{item.title}</span>
            </Link>
          </Menu.Item>
        );
      } else {
        return (
          <SubMenu key={item.key} title={item.title} icon={item.icon}>
            {this.getMenu(item.children)}
          </SubMenu>
        );
      }
    });
  };
  componentWillMount() {
    this.menuDataList = this.getMenu(MenuList);
  }
  render() {
    return (
      <Sider collapsed={this.props.collapsed}>
        <Menu
          defaultSelectedKeys={["1"]}
          defaultOpenKeys={["sub1"]}
          mode="inline"
        >
          {this.menuDataList}
        </Menu>
      </Sider>
    );
  }
}
export default connect((state) => state.left)(LeftPane);
