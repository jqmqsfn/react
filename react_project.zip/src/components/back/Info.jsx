import React, { Component } from "react";
class Info extends Component {
  render() {
    return <div>Info</div>;
  }
}

export default Info;
