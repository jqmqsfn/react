import React, { Component } from "react";
class BackUser extends Component {
  render() {
    return <div>BackUser</div>;
  }
}

export default BackUser;
