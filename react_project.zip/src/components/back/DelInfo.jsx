import { Button, Card, message, Table } from "antd";
import confirm from "antd/lib/modal/confirm";
import axios from "axios";
import React, { Component } from "react";
import { ExclamationCircleOutlined } from "@ant-design/icons";
class BackInfo extends Component {
  constructor() {
    super();
    this.state = {
      info: [],
      columns: [
        {
          title: "编号",
          dataIndex: "id",
          key: "id",
        },
        {
          title: "帖子名称",
          dataIndex: "name",
          key: "name",
        },
        {
          title: "帖子内容",
          dataIndex: "content",
          key: "content",
        },
        {
          title: "操作",
          render: (res) => {
            let that = this;
            return (
              <div>
                <Button
                  type="primary"
                  size="small"
                  style={{ marginRight: "5px" }}
                  onClick={async () => {
                    const result = await axios.put(
                      "http://localhost:3000/backinfo/recoverone",
                      { ids: res.id }
                    );
                    message.info(result.data.msg);
                    that.getData();
                  }}
                >
                  恢复
                </Button>
                <Button
                  danger
                  size="small"
                  onClick={() => {
                    confirm({
                      title: "删除",
                      content: "你确定删除么",
                      onOk: async () => {
                        const result = await axios.delete(
                          "http://localhost:3000/backinfo/del?id=" + res.id
                        );
                        console.log("sdsdsd", result);
                        message.info(result.data.msg);
                        this.getData();
                      },
                      onCancel() {
                        console.log("cancle");
                      },
                    });
                  }}
                >
                  删除
                </Button>
              </div>
            );
          },
        },
      ],
      selectedRowKeys: [],
    };
  }
  componentWillUnmount() {
    this.setState = () => false;
  }
  onSelectChange = (selectedRowKeys) => {
    console.log("selectedRowKeys changed: ", selectedRowKeys);
    this.setState({ selectedRowKeys });
  };
  componentWillMount() {
    this.getData();
  }
  async getData() {
    const result = await axios.get("http://localhost:3000/backinfo/dellist");
    console.log(result);
    this.setState({
      info: result.data,
    });
  }
  render() {
    const { selectedRowKeys } = this.state;
    const rowSelection = {
      selectedRowKeys,
      onChange: this.onSelectChange,
      selections: [
        Table.SELECTION_ALL,
        Table.SELECTION_INVERT,
        Table.SELECTION_NONE,
        {
          key: "odd",
          text: "Select Odd Row",
          onSelect: (changableRowKeys) => {
            let newSelectedRowKeys = [];
            newSelectedRowKeys = changableRowKeys.filter((key, index) => {
              if (index % 2 !== 0) {
                return false;
              }
              return true;
            });
            this.setState({ selectedRowKeys: newSelectedRowKeys });
          },
        },
        {
          key: "even",
          text: "Select Even Row",
          onSelect: (changableRowKeys) => {
            let newSelectedRowKeys = [];
            newSelectedRowKeys = changableRowKeys.filter((key, index) => {
              if (index % 2 !== 0) {
                return true;
              }
              return false;
            });
            this.setState({ selectedRowKeys: newSelectedRowKeys });
          },
        },
      ],
    };
    return (
      <Card
        title="帖子信息"
        extra={
          <Button
            onClick={() => {
              if (this.state.selectedRowKeys.length === 0) {
                message.info("请选择需要恢复的记录");
                return;
              } else {
                let that = this;
                confirm({
                  title: "您确定恢复么",
                  icon: <ExclamationCircleOutlined />,
                  content: "恢复么",
                  async onOk() {
                    const result = await axios.put(
                      "http://localhost:3000/backinfo/recoverall",
                      { ids: that.state.selectedRowKeys }
                    );
                    message.info(result.data.msg);
                    that.getData();
                  },
                  onCancel() {
                    console.log("cancel");
                  },
                });
              }
            }}
          >
            批量恢复
          </Button>
        }
      >
        <Table
          dataSource={this.state.info}
          columns={this.state.columns}
          rowKey="id"
          rowSelection={rowSelection}
        />
      </Card>
    );
  }
}

export default BackInfo;
