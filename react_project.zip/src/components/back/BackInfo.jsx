import { Form, Input, Button, Card, message, Table, Modal } from "antd";
import confirm from "antd/lib/modal/confirm";
import axios from "axios";
import React, { Component } from "react";
import { ExclamationCircleOutlined } from "@ant-design/icons";
class BackInfo extends Component {
  constructor() {
    super();
    this.state = {
      info: [],
      newdata: {},
      columns: [
        {
          title: "编号",
          dataIndex: "id",
          key: "id",
        },
        {
          title: "帖子名称",
          dataIndex: "name",
          key: "name",
        },
        {
          title: "帖子内容",
          dataIndex: "content",
          key: "content",
        },
        {
          title: "操作",
          render: (res) => {
            let that = this;
            return (
              <div>
                <Button
                  type="primary"
                  size="small"
                  style={{ marginRight: "5px" }}
                  onClick={() => {
                    that.setState({
                      isModalVisible: !that.state.isModalVisible,
                    });
                    that.setState({
                      newdata: {
                        id: res.id,
                        name: res.name,
                        content: res.content,
                      },
                    });
                  }}
                >
                  修改
                </Button>
                <Button
                  danger
                  size="small"
                  onClick={() => {
                    confirm({
                      title: "删除",
                      content: "你确定删除么",
                      onOk: async () => {
                        const result = await axios.delete(
                          "http://localhost:3000/backinfo/del?id=" + res.id
                        );
                        console.log("sdsdsd", result);
                        message.info(result.data.msg);
                        this.getData();
                      },
                      onCancel() {
                        console.log("cancle");
                      },
                    });
                  }}
                >
                  删除
                </Button>
              </div>
            );
          },
        },
      ],
      selectedRowKeys: [],
      isModalVisible: false,
    };
    this.formRef = React.createRef();
  }
  componentWillUnmount() {
    this.setState = () => false;
  }
  resetForm = () => {
    this.formRef.current.resetFields();
  };
  onFinish = async (values) => {
    const result = await axios.put(
      "http://localhost:3000/backinfo/upd",
      values
    );
    message.info(result.data.msg);
    this.setState({
      isModalVisible: !this.state.isModalVisible,
    });
    this.setState({
      newdata: {},
    });
    this.resetForm();
    this.getData();
  };

  onFinishFailed = (errorInfo) => {
    console.log("Failed:", errorInfo);
  };

  onSelectChange = (selectedRowKeys) => {
    console.log("selectedRowKeys changed: ", selectedRowKeys);
    this.setState({ selectedRowKeys });
  };
  componentWillMount() {
    this.getData();
  }
  async getData() {
    const result = await axios.get("http://localhost:3000/backinfo/list");
    console.log(result);
    this.setState({
      info: result.data,
    });
  }

  handleOk = () => {
    this.setState({
      isModalVisible: !this.state.isModalVisible,
    });
    this.setState({
      newdata: {},
    });
    this.resetForm();
  };

  handleCancel = () => {
    this.setState({
      isModalVisible: !this.state.isModalVisible,
    });
    this.setState({
      newdata: {},
    });
    this.resetForm();
  };
  render() {
    const { selectedRowKeys } = this.state;
    const rowSelection = {
      selectedRowKeys,
      onChange: this.onSelectChange,
      selections: [
        Table.SELECTION_ALL,
        Table.SELECTION_INVERT,
        Table.SELECTION_NONE,
        {
          key: "odd",
          text: "Select Odd Row",
          onSelect: (changableRowKeys) => {
            let newSelectedRowKeys = [];
            newSelectedRowKeys = changableRowKeys.filter((key, index) => {
              if (index % 2 !== 0) {
                return false;
              }
              return true;
            });
            this.setState({ selectedRowKeys: newSelectedRowKeys });
          },
        },
        {
          key: "even",
          text: "Select Even Row",
          onSelect: (changableRowKeys) => {
            let newSelectedRowKeys = [];
            newSelectedRowKeys = changableRowKeys.filter((key, index) => {
              if (index % 2 !== 0) {
                return true;
              }
              return false;
            });
            this.setState({ selectedRowKeys: newSelectedRowKeys });
          },
        },
      ],
    };
    return (
      <div>
        <Card
          title="帖子信息"
          extra={
            <Button
              onClick={() => {
                if (this.state.selectedRowKeys.length === 0) {
                  message.info("请选择需要删除的记录");
                  return;
                } else {
                  let that = this;
                  confirm({
                    title: "您确定删除么",
                    icon: <ExclamationCircleOutlined />,
                    content: "确定么",
                    async onOk() {
                      const result = await axios.put(
                        "http://localhost:3000/backinfo/delall",
                        { ids: that.state.selectedRowKeys }
                      );
                      message.info(result.data.msg);
                      that.getData();
                    },
                    onCancel() {
                      console.log("cancel");
                    },
                  });
                }
              }}
            >
              批量删除
            </Button>
          }
        >
          <Table
            dataSource={this.state.info}
            columns={this.state.columns}
            rowKey="id"
            rowSelection={rowSelection}
          />
        </Card>
        <Modal
          title="修改帖子信息"
          visible={this.state.isModalVisible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
          destroyOnClose={true}
        >
          <Card title="修改帖子">
            <Form
              name="basic"
              labelCol={{ span: 6 }}
              wrapperCol={{ span: 20 }}
              initialValues={this.state.newdata}
              onFinish={this.onFinish}
              onFinishFailed={this.onFinishFailed}
              ref={this.formRef}
            >
              <Form.Item
                label="帖子编号"
                name="id"
                rules={[{ required: true }]}
              >
                <Input disabled defaultValue={this.state.newdata.id} />
              </Form.Item>
              <Form.Item
                label="帖子名称"
                name="name"
                rules={[{ required: true }]}
              >
                <Input />
              </Form.Item>

              <Form.Item
                label="帖子内容"
                name="content"
                rules={[{ required: true }]}
              >
                <Input.TextArea />
              </Form.Item>
              <Form.Item wrapperCol={{ offset: 8, span: 16 }}>
                <Button type="primary" htmlType="submit">
                  修改帖子
                </Button>
              </Form.Item>
            </Form>
          </Card>
        </Modal>
      </div>
    );
  }
}

export default BackInfo;
