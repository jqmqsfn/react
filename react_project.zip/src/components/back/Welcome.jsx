import React, { Component } from "react";
class Welcome extends Component {
  render() {
    return <div>Welcome</div>;
  }
}

export default Welcome;
