import React, { Component } from "react";
import "../../css/back.css";
import { message, Modal, Button } from "antd";
import { withRouter } from "react-router-dom";
import { mytime } from "../../utils/myinfo";
import { MenuUnfoldOutlined, MenuFoldOutlined } from "@ant-design/icons";
import { connect } from "react-redux";
class BackHeader extends Component {
  constructor(props) {
    super(props);
    this.state = {
      currentTime: mytime(),
      currentUser: null,
    };
  }
  getMytime() {
    this.timeId = setInterval(() => {
      const currentTime = mytime();
      this.setState({
        currentTime,
      });
    }, 1000);
  }
  componentWillMount() {
    if (!sessionStorage.getItem("react20")) {
      message.info("请先登录");
      this.props.history.replace("/login");
    } else {
      this.setState({
        currentUser: JSON.parse(sessionStorage.getItem("react20")).loginname,
      });
    }
  }
  componentDidMount() {
    this.getMytime();
  }
  componentWillUnmount() {
    clearInterval(this.timeId);
  }
  toggleCollapsed = () => {
    this.props.dispatch({
      type: "NAV_TOGGLE",
      collapsed: !this.props.collapsed,
    });
  };
  render() {
    return (
      <div className="back-header">
        <div>
          <h3>
            <Button
              onClick={this.toggleCollapsed}
              style={{ marginRight: "20px" }}
            >
              {React.createElement(
                this.props.collapsed ? MenuUnfoldOutlined : MenuFoldOutlined
              )}
            </Button>
            当前菜单
          </h3>
        </div>
        <div
          style={{
            width: "400px",
            display: "flex",
            justifyContent: "space-between",
          }}
        >
          <span>管理员:{this.state.currentUser}</span>
          <span>时间:{this.state.currentTime}</span>
          <span onClick={this.logout}>退出</span>
        </div>
      </div>
    );
  }
  logout = () => {
    Modal.confirm({
      content: "确定退出么？",
      onOk: () => {
        sessionStorage.removeItem("react20");
        this.props.history.replace("/login");
      },
    });
  };
}

export default withRouter(connect((state) => state.left)(BackHeader));
