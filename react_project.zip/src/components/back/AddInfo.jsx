import { Form, Input, Button, Card, message } from "antd";
import axios from "axios";
import React, { Component } from "react";

class AddInfo extends Component {
  constructor() {
    super();
    this.state = {};
    this.formRef = React.createRef();
  }
  onFinish = async (values) => {
    const result = await axios.post(
      "http://localhost:3000/backinfo/add",
      values
    );
    message.info(result.data.msg);
    this.resetForm();
  };

  onFinishFailed = (errorInfo) => {
    console.log("Failed:", errorInfo);
  };

  resetForm = () => {
    this.formRef.current.resetFields();
  };

  render() {
    return (
      <div>
        <Card title="添加帖子">
          <Form
            name="basic"
            labelCol={{ span: 2 }}
            wrapperCol={{ span: 22 }}
            initialValues={{ remember: true }}
            onFinish={this.onFinish}
            onFinishFailed={this.onFinishFailed}
            ref={this.formRef}
          >
            <Form.Item
              label="帖子名称"
              name="name"
              rules={[{ required: true }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              label="帖子内容"
              name="content"
              rules={[{ required: true }]}
            >
              <Input.TextArea />
            </Form.Item>
            <Form.Item wrapperCol={{ offset: 8, span: 16 }}>
              <Button type="primary" htmlType="submit">
                提交帖子
              </Button>
            </Form.Item>
          </Form>
        </Card>
      </div>
    );
  }
}
export default AddInfo;
