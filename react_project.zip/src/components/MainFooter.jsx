import React, { Component } from "react";
import { Layout } from "antd";
import "../css/mainheader.css";
export default class MainFooter extends Component {
  render() {
    return (
      <Layout.Footer style={{ textAlign: "center" }}>
        南京万和IPC备0100010 2021-08-11 wanho.com 版权所有
      </Layout.Footer>
    );
  }
}
