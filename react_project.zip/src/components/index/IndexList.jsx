import React, { Component } from "react";
import { List, Avatar } from "antd";
import { list } from "../../api/info";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import "../../css/indexlist.css";
import MyTag from "./MyTag";
class IndexList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
    };
  }
  componentWillMount() {
    this.getData(this.props.tag);
  }
  getData(tag) {
    // if (!(this.props.data && this.props.data.length > 0)) {
    this.props.dispatch(async (dispatch) => {
      const result = await list(tag);
      dispatch({
        type: "LIST_SUCCESS",
        data: result.data,
      });
    });
    // }
  }
  shouldComponentUpdate(nextProps, nextState) {
    if (this.props.tag !== nextProps.tag) {
      this.getData(nextProps.tag);
      return false;
    }
    return true;
  }
  render() {
    console.log("dsds", this.props);
    return (
      <div style={{ padding: "10px" }}>
        <List
          loading={this.props.loading}
          dataSource={this.props.data}
          renderItem={(item) => (
            <List.Item>
              <List.Item.Meta
                avatar={
                  <Avatar src="https://zos.alipayobjects.com/rmsportal/ODTLcjxAfvqbxHnVXCYX.png" />
                }
                title={
                  <div>
                    {/* {item.tab === "top" ? <Tag color="magenta">置顶</Tag> : ""}
                    {item.tab === "share" ? <Tag color="purple">分享</Tag> : ""}
                    {item.tab === "good" ? <Tag color="blue">精华</Tag> : ""}
                    {item.tab === "ask" ? <Tag color="green">问答</Tag> : ""}
                    {item.tab === "job" ? <Tag color="orange">招聘</Tag> : ""}
                    {item.tab === "test" ? <Tag color="red">测试</Tag> : ""} */}
                    <MyTag data={item.tab} />
                    <Link to={"/detail/" + item.id}>{item.title}</Link>
                  </div>
                }
                description={
                  <div>
                    <Link to={"/user/" + item.u_id}>{item.loginname}</Link>
                    <span style={{ marginLeft: "10px" }}>
                      发表于：{item.createdate.split("T")[0]}
                    </span>
                  </div>
                }
              />
              <div style={{ marginRight: "20px" }}>
                回复：{item.reply_count} | 访问：{item.visit_count}
              </div>
            </List.Item>
          )}
        ></List>
      </div>
    );
  }
}

export default connect((state) => state.list)(IndexList);
