import React, { Component } from "react";
import { Tag } from "antd";
const tab = {
  top: {
    color: "magenta",
    txt: "置顶",
  },
  share: {
    color: "purple",
    txt: "分享",
  },
  good: {
    color: "blue",
    txt: "精华",
  },
  ask: {
    color: "green",
    txt: "问答",
  },
  job: {
    color: "orange",
    txt: "招聘",
  },
  dev: {
    color: "red",
    txt: "测试",
  },
};
export default class MyTag extends Component {
  render() {
    const newTab = tab[this.props.data] || tab["good"];
    return <Tag color={newTab.color}>{newTab.txt}</Tag>;
  }
}
