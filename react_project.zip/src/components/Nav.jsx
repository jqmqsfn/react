import React, { Component } from "react";
import { Menu } from "antd";
import "../css/mainheader.css";
import { Link } from "react-router-dom";
import {
  HomeOutlined,
  BookOutlined,
  InfoCircleOutlined,
} from "@ant-design/icons";
export default class Nav extends Component {
  render() {
    let { mode, theme } = this.props;
    return (
      <Menu mode={mode} theme={theme}>
        <Menu.Item key="home" icon={<HomeOutlined />}>
          <Link to="/inde/all">首页</Link>
        </Menu.Item>
        <Menu.Item key="book" icon={<BookOutlined />}>
          <Link to="/book">教程</Link>
        </Menu.Item>
        <Menu.Item key="about" icon={<InfoCircleOutlined />}>
          <Link to="/about">关于</Link>
        </Menu.Item>
      </Menu>
    );
  }
}
