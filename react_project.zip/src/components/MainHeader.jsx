import React, { Component } from "react";
import { Layout, Row, Col, Divider, Dropdown, Button } from "antd";
import "../css/mainheader.css";
import Nav from "./Nav";

import { MenuFoldOutlined } from "@ant-design/icons";
import { withRouter } from "react-router-dom";
class MainHeader extends Component {
  render() {
    return (
      <Layout.Header>
        <Row>
          <Col md={6} xs={24}>
            <h1 className="logo">wanho</h1>
          </Col>

          <Col md={18} xs={0}>
            <Divider className="u-line" type="vertical" />
            <Nav mode="horizontal" theme="dark" />
          </Col>
          <Col md={0} xs={24} className="xsPane">
            <Dropdown overlay={<Nav mode="vertical" theme="dark" />}>
              <Button className="u-main-but">
                <MenuFoldOutlined />
              </Button>
            </Dropdown>
          </Col>
        </Row>
      </Layout.Header>
    );
  }
}
export default withRouter(MainHeader);
