import React, { Component } from "react"
import { Route, Redirect, Switch } from "react-router-dom"
import Index from "../views/Index"
import About from "../views/About"
import Detail from "../views/Detail"
import Book from "../views/Book"
import User from "../views/User"
import Login from "../views/LogIin"
import Main from "../views/Main"

class RouterIndex extends Component {
    render() {
        return (
            <Switch>
                <Route path="/login" component={Login} />
                <Route path="/back" component={Main} />
                <Route path="/index/:id" component={Index} />
                <Route path="/about" component={About} />
                <Route path="/detail/:id" component={Detail} />
                <Route path="/book" component={Book} />
                <Route path="/user/:id" component={User} />
                <Route path="/" render={
                    () => {
                        return <Redirect to="/index/all" />
                    }
                } />
            </Switch>
        )
    }
}
export default RouterIndex