import React, { Component } from "react";
import { Layout } from "antd";
import LeftPane from "../components/back/LeftPane";
import BackHeader from "../components/back/BackHeader";
import { Redirect, Route } from "react-router-dom";
import Welcome from "../components/back/Welcome";
// import Info from "../components/back/Info";
import BackUser from "../components/back/BackUser";
import BackInfo from "../components/back/BackInfo";
import DelInfo from "../components/back/DelInfo";
import AddInfo from "../components/back/AddInfo";
// eslint-disable-next-line
const { Header, Footer, Sider, Content } = Layout;
class Main extends Component {
  render() {
    return (
      <Layout>
        <LeftPane />
        <Layout>
          <Header style={{ background: "white" }}>
            <BackHeader />
          </Header>
          <Content>
            <Route
              path="/back"
              render={() => {
                if (sessionStorage.getItem("react20")) {
                  return <Redirect to="/back/welcome" />;
                } else {
                  return <Redirect to="/" />;
                }
              }}
            />
            <Route path="/back/welcome" component={Welcome} />
            {/* <Route path="/back/info" component={Info} /> */}
            <Route path="/back/backuser" component={BackUser} />
            <Route path="/back/info" component={BackInfo} />
            <Route path="/back/delinfo" component={DelInfo} />
            <Route path="/back/addinfo" component={AddInfo} />
          </Content>
          <Footer>Footer</Footer>
        </Layout>
      </Layout>
    );
  }
}
export default Main;
