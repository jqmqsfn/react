// eslint-disable-next-line
import { Button, Table, Pagination } from "antd";
import React, { Component } from "react";
import { FormOutlined, DeleteOutlined } from "@ant-design/icons";
class About extends Component {
  constructor() {
    super();
    this.state = {
      data: [
        {
          key: "1",
          name: "胡彦斌",
          age: 32,
          address: "西湖区湖底公园1号",
        },
        {
          key: "2",
          name: "胡彦祖",
          age: 42,
          address: "西湖区湖底公园2号",
        },
        {
          key: "3",
          name: "胡彦斌",
          age: 32,
          address: "西湖区湖底公园3号",
        },
        {
          key: "4",
          name: "胡彦祖",
          age: 42,
          address: "西湖区湖底公园4号",
        },
        {
          key: "5",
          name: "胡彦斌",
          age: 32,
          address: "西湖区湖底公园5号",
        },
        {
          key: "6",
          name: "胡彦祖",
          age: 42,
          address: "西湖区湖底公园6号",
        },
      ],
      columns: [
        {
          title: "姓名",
          dataIndex: "name",
          key: "name",
        },
        {
          title: "年龄",
          dataIndex: "age",
          key: "age",
        },
        {
          title: "住址",
          dataIndex: "address",
          key: "address",
        },
        {
          title: "操作",
          render: (user) => (
            <div>
              <Button
                type="primary"
                size="small"
                icon={<FormOutlined />}
                onClick={() => {
                  console.log("user", user);
                }}
              >
                修改
              </Button>
              &nbsp;&nbsp;
              <Button
                type="primary"
                danger
                size="small"
                icon={<DeleteOutlined />}
              >
                删除
              </Button>
            </div>
          ),
          key: "set",
        },
      ],
    };
  }
  render() {
    return (
      <Table
        columns={this.state.columns}
        dataSource={this.state.data}
        pagination={{ defaultPageSize: 3, showQuickJumper: true }}
      />
    );
  }
}

export default About;
