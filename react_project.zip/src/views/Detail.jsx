import React, { Component } from "react";
import { Card, Avatar } from "antd";
import { Link } from "react-router-dom";
import { queryone } from "../api/info";
import { connect } from "react-redux";
import MyTag from "../components/index/MyTag";
import Reply from "../components/detail/Reply";
class Detail extends Component {
  componentWillMount() {
    this.getData();
  }
  async getData() {
    this.props.dispatch(async (dispatch) => {
      const result = await queryone(this.props.match.params.id);
      dispatch({
        type: "DETAIL",
        data: result.data,
      });
    });
  }
  render() {
    const { loading, data } = this.props;
    data.content = data.content ? data.content.replace(/\\n/g, "<br />") : "";
    const title = (
      <div>
        <h1>{data.title}</h1>
        <div>
          <MyTag data={data.tab} />
          <Avatar src="https://zos.alipayobjects.com/rmsportal/ODTLcjxAfvqbxHnVXCYX.png" />
          <Link to="/user">{data.loginname}</Link>
          <span style={{ marginLeft: "10px" }}>
            发表于：{data.createdate.split("T")[0]}
          </span>
        </div>
      </div>
    );
    return (
      <div>
        <Card title={title}>
          <div dangerouslySetInnerHTML={{ __html: data.content }} />
          <Reply
            replycount={data.reply_count}
            loading={loading}
            data={data.reply_list}
          />
        </Card>
      </div>
    );
  }
}

export default connect((state) => state.detail)(Detail);
