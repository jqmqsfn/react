import React, { Component } from "react";
import { Card, Avatar, Row, Col } from "antd";
import { userone } from "../api/info";
import { connect } from "react-redux";
import Near from "../components/user/Near";
import Nreply from "../components/user/Nreply";
import "../css/user.css";
class User extends Component {
  componentWillMount() {
    this.getData();
  }
  async getData() {
    this.props.dispatch(async (dispatch) => {
      const result = await userone(this.props.match.params.id);
      dispatch({
        type: "USER",
        data: result.data,
      });
    });
  }
  render() {
    const { loading, data } = this.props;
    console.log(data, loading);
    return (
      <div>
        <Row style={{ textAlign: "center" }}>
          <Col span={24} className="u-headpic">
            <Avatar src="https://zos.alipayobjects.com/rmsportal/ODTLcjxAfvqbxHnVXCYX.png" />
          </Col>
          <Col span={8}>
            用户名：<span style={{ color: "#4CAEFF" }}>{data.loginname}</span>
          </Col>
          <Col span={8}>
            积分：<span style={{ color: "#4CAEFF" }}>{data.points}</span>
          </Col>
          <Col span={8}>
            注册时间：
            <span style={{ color: "#4CAEFF" }}>
              {data.registdate.split("T")[0]}
            </span>
          </Col>
        </Row>
        <Card title="最近创建的话题">
          <Near data={data.info_list} loading={loading} />
        </Card>
        <Card title="最近回复的话题">
          <Nreply data={data.reply_list} loading={loading} />
        </Card>
      </div>
    );
  }
}

export default connect((state) => state.user)(User);
