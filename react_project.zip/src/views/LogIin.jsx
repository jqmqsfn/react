import React, { Component } from "react";
import { Form, Input, Button, Checkbox, message } from "antd";
import "../css/login.css";
import { login } from "../api/user";

class Login extends Component {
  onFinish = async (values) => {
    console.log("Success:", values);
    const result = await login(values);
    if (result.errorNo === 0) {
      message.info(result.message);
      sessionStorage.setItem("react20", JSON.stringify(result.data));
      this.props.history.replace("/back");
    } else {
      message.error(result.message);
    }
  };
  onFinishFailed(errorInfo) {
    console.log("Failed:", errorInfo);
  }
  render() {
    return (
      <div className="g-login">
        <h3 style={{ textAlign: "center" }}>管理员登录</h3>
        <Form
          name="basic"
          labelCol={{ span: 8 }}
          wrapperCol={{ span: 8 }}
          initialValues={{ remember: true }}
          onFinish={this.onFinish}
          onFinishFailed={this.onFinishFailed}
        >
          <Form.Item
            label="用户"
            name="loginname"
            rules={[{ required: true, message: "Please input your username!" }]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            label="密码"
            name="pass"
            rules={[{ required: true, message: "Please input your password!" }]}
          >
            <Input.Password />
          </Form.Item>

          <Form.Item
            name="remember"
            valuePropName="checked"
            wrapperCol={{ offset: 8, span: 16 }}
          >
            <Checkbox>Remember me</Checkbox>
          </Form.Item>

          <Form.Item wrapperCol={{ offset: 8, span: 16 }}>
            <Button type="primary" htmlType="submit">
              Submit
            </Button>
          </Form.Item>
        </Form>
      </div>
    );
  }
}
export default Login;
