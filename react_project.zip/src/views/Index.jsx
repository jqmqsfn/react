import React, { Component } from "react";
import { Row, Col, Menu } from "antd";
import { Link } from "react-router-dom";
import IndexList from "../components/index/IndexList";
import "../css/index.css";
class Index extends Component {
  //   constructor(props) {
  //     super(props);
  //     this.state = {
  //       tag: props.match.params.id,
  //     };
  //   }
  render() {
    let tag = this.props.match.params.id;
    return (
      <div>
        <Row>
          <Col md={6} xs={24}>
            <Menu className="m-text">
              <Menu.Item key="1">
                <Link to="/index/all">全部</Link>
              </Menu.Item>
              <Menu.Item key="2">
                <Link to="/index/good">精华</Link>
              </Menu.Item>
              <Menu.Item key="3">
                <Link to="/index/ask">问答</Link>
              </Menu.Item>
              <Menu.Item key="4">
                <Link to="/index/share">分享</Link>
              </Menu.Item>
              <Menu.Item key="5">
                <Link to="/index/job">招聘</Link>
              </Menu.Item>
              <Menu.Item key="6">
                <Link to="/index/dev">测试</Link>
              </Menu.Item>
            </Menu>
          </Col>
          <Col md={18}>
            <IndexList tag={tag} />
          </Col>
        </Row>
      </div>
    );
  }
}

export default Index;
