import React, { Component } from "react";
class Book extends Component {
  render() {
    return <div>Book</div>;
  }
}

export default Book;
