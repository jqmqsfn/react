import React from "react"
import {
    AppstoreOutlined,
    MailOutlined,
    SettingOutlined,
    BorderOuterOutlined,
    PlusSquareOutlined,
    SlackOutlined,
    DribbbleOutlined,
    QqOutlined,
    BarChartOutlined,
    PieChartOutlined,
    LineChartOutlined, DeleteOutlined
} from '@ant-design/icons';
const menuList = [
    {
        title: "首页",
        key: "/back/welcome",
        icon: <MailOutlined />
    },
    {
        title: "帖子管理",
        key: "/info",
        icon: <AppstoreOutlined />,
        children: [
            {
                title: "帖子操作",
                key: "/back/info",
                icon: <BorderOuterOutlined />
            },
            {
                title: "添加帖子",
                key: "/back/addinfo",
                icon: <PlusSquareOutlined />
            },
            {
                title: "已删帖子",
                key: "/back/delinfo",
                icon: <DeleteOutlined />
            }
        ]
    },
    {
        title: "用户",
        key: "/user",
        icon: <QqOutlined />,
        children: [
            {
                title: "用户管理",
                key: "/back/backuser",
                icon: <SlackOutlined />
            },
            {
                title: "添加用户",
                key: "/back/adduser",
                icon: <DribbbleOutlined />
            }
        ]
    },
    {
        title: "图表",
        key: "/chart",
        icon: <SettingOutlined />,
        children: [
            {
                title: "柱形图",
                key: "/back/bar",
                icon: <BarChartOutlined />
            },
            {
                title: "饼图",
                key: "/back/pie",
                icon: <PieChartOutlined />
            },
            {
                title: "折线图",
                key: "/back/line",
                icon: <LineChartOutlined />
            }
        ]
    }
]
export default menuList