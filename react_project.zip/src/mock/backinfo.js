import Mock from "mockjs"
const backinfo = Mock.mock({
    "data|100": [
        {
            "id|+1": 1,//生成商品id，自增1
            "name": "@cword(3, 5)",//生成商品名 ， 都是中国人的名字
            "content": '@csentence',
            "type|1": [0, 1]
        },
    ]
})
// const backinfo = [
//     { id: 1, name: "xxx", content: "xxxxxxxxxx", type: 0 },
//     { id: 2, name: "aaa", content: "aaaaaaaaa", type: 0 },
//     { id: 3, name: "bbb", content: "bbbbbbbbbb", type: 0 },
//     { id: 4, name: "ccc", content: "ccccccccc", type: 0 },
//     { id: 5, name: "ddd", content: "ddddddddd", type: 0 },
//     { id: 6, name: "eee", content: "eeeeeeeeee", type: 0 },
//     { id: 7, name: "fff", content: "fffffffff", type: 0 },
// ]
Mock.mock("http://localhost:3000/backinfo/list", 'get', function (res) {
    return backinfo.data.filter(item => item.type === 0)
})
Mock.mock("http://localhost:3000/backinfo/delall", 'put', function (option) {
    const ids = JSON.parse(option.body).ids
    for (let i = 0; i < backinfo.data.length; i++) {
        for (let j = 0; j < ids.length; j++) {
            if (backinfo.data[i].id === ids[j]) {
                backinfo.data[i].type = 1
            }
        }
    }
    return { msg: "批量删除成功" }
})
Mock.mock("http://localhost:3000/backinfo/dellist", 'get', function (res) {
    return backinfo.data.filter(item => item.type === 1)
})
Mock.mock("http://localhost:3000/backinfo/recoverall", 'put', function (option) {
    const ids = JSON.parse(option.body).ids
    for (let i = 0; i < backinfo.data.length; i++) {
        for (let j = 0; j < ids.length; j++) {
            if (backinfo.data[i].id === ids[j]) {
                backinfo.data[i].type = 0
            }
        }
    }
    return { msg: "批量恢复成功" }
})
Mock.mock("http://localhost:3000/backinfo/recoverone", 'put', function (option) {
    const ids = JSON.parse(option.body).ids
    for (let i = 0; i < backinfo.data.length; i++) {
        if (backinfo.data[i].id === ids) {
            backinfo.data[i].type = 0
        }
    }
    return { msg: "恢复成功" }
})
// eslint-disable-next-line
Mock.mock(RegExp("http://localhost:3000/backinfo/del" + ".*"), 'delete', (option) => {
    let id = option.url.split('=')[1]
    for (let i = 0; i < backinfo.data.length; i++) {
        if (backinfo.data[i].id === parseInt(id)) {
            backinfo.data.splice(i, 1)
            return {
                msg: "删除成功"
            }
        }
    }
})

Mock.mock("http://localhost:3000/backinfo/add", 'post', (option) => {
    const oneList = JSON.parse(option.body)
    oneList.id = backinfo.data[backinfo.data.length - 1].id + 1
    oneList.type = 0
    backinfo.data.push(oneList)
    return {
        msg: "添加用户成功"
    }
})
Mock.mock("http://localhost:3000/backinfo/upd", "put", (option) => {
    console.log(option.body);
    const onelist = JSON.parse(option.body)
    for (let i = 0; i < backinfo.data.length; i++) {
        if (backinfo.data[i].id === onelist.id) {
            backinfo.data[i].name = onelist.name
            backinfo.data[i].content = onelist.content
        }
    }
    return {
        msg: "更新用户成功"
    }
})