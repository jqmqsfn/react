function user(state = {
    data: {
        loginname: "",
        points: "",
        registdate: ""
    },
    loading: true
}, action) {
    switch (action.type) {
        case "USER":
            return {
                data: action.data,
                loading: false
            }
        default:
            return state
    }
}
export default user