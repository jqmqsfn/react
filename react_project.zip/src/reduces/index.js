import { combineReducers } from "redux";
import list from "./list"
import user from "./user"
import detail from "./detail"
import left from "./left"
let reducer = combineReducers({
    list, user, detail, left
})
export default reducer