let left = (state = { collapsed: false }, action) => {
    switch (action.type) {
        case "NAV_TOGGLE":
            return { collapsed: action.collapsed }
        default:
            return state
    }
}
export default left