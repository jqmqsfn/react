function detail(state = {
    data: { "createdate": "2017-07-15T16:00:00.000Z" },
    loading: true
}, action) {
    switch (action.type) {
        case "DETAIL":
            return {
                data: action.data,
                loading: false
            }
        default:
            return state
    }
}
export default detail