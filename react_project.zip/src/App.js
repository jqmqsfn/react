import "./App.css"
import React, { Component } from "react"
import RouterIndex from "./router"
import MainHeader from './components/MainHeader';
import MainFooter from "./components/MainFooter";

class App extends Component {
  render() {
    return (
      <div>
        <MainHeader />
        <div className="main">
          <RouterIndex />
        </div>
        <MainFooter />
      </div>
    );
  }
}


export default App;
