import React, { Component } from "react";
import HomeHeader from "../components/index/home-header";
import HomeSwiper from "../components/index/home-swiper";
import Wraparea from "../components/index/Wraparea";
import HomeHua from "../components/index/HomeHua";
import HomeParent from "../components/index/home-parent";
import HomeWeek from "../components/index/homeweek";
import FlowerBanner from "../components/index/flower-banner";
export default class Index extends Component {
  render() {
    return (
      <div>
        <HomeHeader />
        <HomeSwiper />
        <Wraparea />
        <HomeHua />
        <HomeParent />
        <HomeWeek />
        <FlowerBanner />
      </div>
    );
  }
}
