
import React, { Component } from "react";
import Index from "./views/Index"
import { Route } from "react-router-dom"

class App extends Component {
  render() {
    return (
      <div>
        <div>
          <Route path="/index" component={Index} />
        </div>
      </div>
    );
  }
}
export default App;
