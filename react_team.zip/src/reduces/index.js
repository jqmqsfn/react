import { combineReducers } from "redux";
let data = (data = [], action) => {
    // console.log("action", action);
    switch (action.type) {
        case "add":
            return [...data, { id: action.id, name: action.name }]
        case "del":
            return data.filter((item) => item.id !== action.id)
        default:
            return data
    }
}
let reducer = combineReducers({
    data
})
export default reducer