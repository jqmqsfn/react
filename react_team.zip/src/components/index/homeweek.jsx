import React, { Component } from "react";
import "../../less/index/homeweek.less";
import { weekData } from "../../datas/index";
export default class homeweek extends Component {
  render() {
    return (
      <div id="love">
        {weekData.map((item, index) => {
          return (
            <div className="" key={index}>
              <div className="love_top">
                <div>
                  <h1>{item.name}</h1>
                  <span>{item.descp}</span>
                  <p className="fr">
                    <a href="/">查看更多</a>
                  </p>
                </div>
              </div>
              <div className="love_middle">
                <a href="/">
                  <img src={item.img.default} alt="" />
                </a>
              </div>
              <div className="love_bottom clearbox">
                {item.flowerList.map((week, idx) => {
                  return (
                    <div className="love_box" key={idx}>
                      <div>
                        <img src={week.pic.default} alt="" />
                      </div>
                      <p>{week.title}</p>
                      <p>
                        <span>&yen;{week.price}</span>
                        <span>原价 &yen;{week.sale}</span>
                      </p>
                      <p>{week.num}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    );
  }
}
