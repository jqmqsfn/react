import React, { Component } from "react";
import "../../less/index/home-header.less";
import { headData } from "../../datas/index";
export default class HomeHeader extends Component {
  render() {
    return (
      <div id="header">
        <div className="header_top_box">
          <div className="header_top">
            <p className="header_top_left fl">
              <span>商务 024-31128100 </span>
              <span>全国订购热线</span>
              <b>400-888-1571</b>
            </p>
            <p className="header_top_right fr">
              <a href="/">联系客服</a>
              <a href="/">我的订单</a>
              <a href="/">登录/注册</a>
              <a href="/">
                <span className="iconfont icon-gouwuche"></span>
                <span>购物车</span>(<b>0</b>)
              </a>
            </p>
          </div>
        </div>

        <div className="header_middle">
          <div className="fl">
            <input
              className="fl"
              type="search"
              placeholder="请输入关键词搜索"
            />
            <button className="fl">
              <span className="iconfont icon-sousuo"></span>
              <span>搜索</span>
            </button>
          </div>
          <ul className="fr">
            <li>
              <span className="iconfont icon-shizhong"></span>
              <span>全国1小时到达</span>
            </li>
            <li>
              <span className="iconfont icon-xiangxia"></span>
              <span>低价折扣</span>
            </li>
            <li>
              <span className="iconfont icon-dunpai"></span>
              <span>退款服务</span>
            </li>
          </ul>
        </div>

        <div className="header_bottom">
          <p>
            <span className="iconfont icon-daohang"></span>
            <span>鲜花导航</span>
          </p>
          <p>
            {headData.map((item, index) => {
              return (
                <a href="/" key={index}>
                  {item}
                </a>
              );
            })}
          </p>
        </div>
      </div>
    );
  }
}
