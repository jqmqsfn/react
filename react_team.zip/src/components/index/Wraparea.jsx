import React, { Component } from "react";
import "../../less/index/wraparea.less";
import { wrapData } from "../../datas/index";
export default class Wraparea extends Component {
  render() {
    return (
      <div>
        {wrapData.map((item, index) => {
          return (
            <div id="wrap" key={index}>
              <div className="wrap_top">
                <div>
                  <h1>{item.name}</h1>
                  <span>{item.descp}</span>
                </div>
              </div>
              <div className="wrap_bottom clearbox">
                {item.wraplist.map((content, idx) => {
                  return (
                    <div className="wrap_box" key={idx}>
                      <div>
                        <img src={content.pic.default} alt="" />
                      </div>
                      {content.type === 1 ? (
                        <b>
                          <span className="tejia"></span>
                          <span className="tejia_font ">特价</span>
                        </b>
                      ) : (
                        <b>
                          <span className="tejia"></span>
                          <span className="tejia_font">爆款</span>
                        </b>
                      )}

                      <p>{content.title}</p>
                      <p>
                        <span>&yen;{content.price}</span>
                        <span>{content.sale}</span>
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    );
  }
}
