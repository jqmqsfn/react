import React, { Component } from "react";
import "../../less/index/homeswiper.less";
import { navData } from "../../datas/index";
export default class HomeSwiper extends Component {
  render() {
    return (
      <div id="banner">
        <ul>
          <li>
            <img
              src={require("../../imgs/index/banner/bg1.jpg").default}
              alt=""
            />
          </li>
          <li>
            <img
              src={require("../../imgs/index/banner/bg2.jpg").default}
              alt=""
            />
          </li>
          <li>
            <img
              src={require("../../imgs/index/banner/bg3.jpg").default}
              alt=""
            />
          </li>
          <li>
            <img
              src={require("../../imgs/index/banner/bg4.jpg").default}
              alt=""
            />
          </li>
        </ul>
        <div className="nav">
          {navData.map((item, index) => {
            return (
              <div key={index}>
                <h3>{item.name}</h3>
                <p>
                  {item.list.map((itm, idx) => {
                    return (
                      <a href="/" key={idx}>
                        {itm}
                      </a>
                    );
                  })}
                </p>
              </div>
            );
          })}
        </div>
        <p className="left_er">
          <span className="iconfont icon-zuojiantou"></span>
        </p>
        <p className="right_er">
          <span className="iconfont icon-zuojiantou-copy"></span>
        </p>
        <p className="spolt">
          <span className="current"></span>
          <span></span>
          <span></span>
          <span></span>
        </p>
      </div>
    );
  }
}
