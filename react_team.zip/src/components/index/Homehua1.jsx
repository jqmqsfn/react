import React, { Component } from "react";
import "../../less/index/homehua.less";
import { Link } from "react-router-dom";
import ProTypes from "prop-types";
let pt = {
  id: ProTypes.number,
  name: ProTypes.string,
  img: ProTypes.object,
  num: ProTypes.string,
  price: ProTypes.string,
  type: ProTypes.number,
  sale: ProTypes.string,
};

export default class HomeHua1 extends Component {
  render() {
    return (
      <div className="love_box">
        <Link to={"/detail/" + this.props.id}>
          <div>
            <img src={this.props.pic.default} alt="" />
          </div>
          {this.props.type === 1 ? (
            <b>
              <span className="tejia"></span>
              <span className="tejia_font ">特价</span>
            </b>
          ) : (
            ""
          )}
          {this.props.type === 2 ? (
            <b>
              <span className="tejia"></span>
              <span className="tejia_font">爆款</span>
            </b>
          ) : (
            ""
          )}
          {this.props.type === 3 ? (
            <b>
              <span className="tejia"></span>
              <span className="tejia_font">推荐</span>
            </b>
          ) : (
            ""
          )}
          {this.props.type === 4 ? (
            <b>
              <span className="tejia"></span>
              <span className="tejia_font">热销</span>
            </b>
          ) : (
            ""
          )}

          <p>{this.props.title}</p>
          <p>
            <span>&yen;{this.props.price}</span>
            <span>原价 &yen;{this.props.sale}</span>
          </p>
          <p>{this.props.num}</p>
        </Link>
      </div>
    );
  }
}
HomeHua1.propTypes = pt;
