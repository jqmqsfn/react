import React, { Component } from "react";
import "../../less/index/home-parent.less";
import { parsentData } from "../../datas/index";
export default class HomeParent extends Component {
  render() {
    return (
      <div id="love">
        {parsentData.map((item, index) => {
          return (
            <div className="" key={index}>
              <div className="love_top">
                <div>
                  <h1>{item.name}</h1>
                  <span> {item.descp}</span>
                  {item.priceList.map((pri, idx) => {
                    return (
                      <p className="fr" key={idx}>
                        <a href="/">{pri}</a>
                      </p>
                    );
                  })}
                </div>
              </div>
              <div className="love_m fl">
                <a href="/">
                  <img
                    src={require("../../imgs/index/love/l1.png").default}
                    alt=""
                  />
                </a>
                <div>
                  <a href="/">
                    <img
                      src={require("../../imgs/index/love/l2.png").default}
                      alt=""
                    />
                    <span>生日礼物</span>
                  </a>
                  <a href="/">
                    <img
                      src={require("../../imgs/index/love/l3.png").default}
                      alt=""
                    />
                    <span>约会/求爱</span>
                  </a>
                  <a href="/">
                    <img
                      src={require("../../imgs/index/love/l4.png").default}
                      alt=""
                    />
                    <span>结婚礼品</span>
                  </a>
                  <a href="/">
                    <img
                      src={require("../../imgs/index/love/l5.png").default}
                      alt=""
                    />
                    <span>感谢/祝福</span>
                  </a>
                  <a href="/">
                    <img
                      src={require("../../imgs/index/love/l6.png").default}
                      alt=""
                    />
                    <span>拜访/探望</span>
                  </a>
                  <a href="/">
                    <img
                      src={require("../../imgs/index/love/l7.png").default}
                      alt=""
                    />
                    <span>纪念日礼物</span>
                  </a>
                </div>
              </div>
              {item.ringList.map((ring, sidx) => {
                return (
                  <div className="love_box fl" key={sidx}>
                    <div>
                      <img src={ring.pic.default} alt="" />
                    </div>
                    <p>{ring.title}</p>
                    <p>
                      <span>&yen;{ring.price}</span>
                      <span>原价 &yen;{ring.sale}</span>
                    </p>
                    <p>{ring.num}</p>
                  </div>
                );
              })}
            </div>
          );
        })}
      </div>
    );
  }
}
