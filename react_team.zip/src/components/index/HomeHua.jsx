import React, { Component } from "react";
import "../../less/index/homehua.less";
import { picDate } from "../../datas/index";
import HomeHua1 from "./Homehua1";
export default class HomeHua extends Component {
  render() {
    return (
      <div id="love">
        {picDate.map((item, index) => {
          return (
            <div className="" key={index}>
              <div className="love_top">
                <div>
                  <h1>{item.name}</h1>
                  <span> {item.descp}</span>
                  {item.priceList.map((pri, idx) => {
                    return (
                      <p className="fr" key={idx}>
                        <a href="/">{pri}</a>
                      </p>
                    );
                  })}
                </div>
              </div>
              <div className="love_middle">
                <a href="/">
                  <img src={item.img.default} alt="" />
                </a>
              </div>
              <div className="love_bottom clearbox">
                {item.flowerList.map((flower, sindex) => {
                  return <HomeHua1 key={sindex} {...flower} />;
                })}
              </div>
            </div>
          );
        })}
      </div>
    );
  }
}
