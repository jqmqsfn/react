import React, { Component } from "react";
import "../../less/index/flower-banner.less";
export default class flowerbanner extends Component {
  render() {
    return (
      <div id="love">
        <div className="love_top">
          <div>
            <h1>编辑推荐</h1>
            <span> 囊括美好的鲜花</span>
            <p className="fr">
              <a href="/">查看更多</a>
            </p>
          </div>
        </div>
        <div id="edit">
          <div className="edit_left fl clearbox">
            <a href="/" className="fl">
              <img
                src={require("../../imgs/index/love/x1.png").default}
                alt=""
              />
            </a>
            <a href="/" className="fl">
              <img
                src={require("../../imgs/index/love/x2.png").default}
                alt=""
              />
            </a>
          </div>
          <div className="edit_right fr clearbox">
            <a href="/" className="fr">
              <img
                src={require("../../imgs/index/love/y1.png").default}
                alt=""
              />
            </a>
            <a href="/" className="fr">
              <img
                src={require("../../imgs/index/love/y2.png").default}
                alt=""
              />
            </a>
          </div>
          <div className="edit_bottom clearbox">
            <a href="/">
              <img
                src={require("../../imgs/index/love/z1.png").default}
                alt=""
              />
            </a>
            <a href="/">
              <img
                src={require("../../imgs/index/love/z2.png").default}
                alt=""
              />
            </a>
            <a href="/">
              <img
                src={require("../../imgs/index/love/z3.png").default}
                alt=""
              />
            </a>
            <a href="/">
              <img
                src={require("../../imgs/index/love/z4.png").default}
                alt=""
              />
            </a>
          </div>
        </div>
      </div>
    );
  }
}
