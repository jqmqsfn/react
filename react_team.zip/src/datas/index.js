const headData = [
    "首页",
    "鲜花",
    "永生花",
    "礼品",
    "每周一花",
    "花语",
    "企业团购",
]
const wrapData = [
    {
        id: 1, name: "今日疯抢", descp: "凡今日下单均赠送价值300元优惠券",
        wraplist: [
            { id: 1, pic: require("../imgs/index/wrap/t1.jpg"), title: "情意绵绵·9枝红玫瑰纯美花束", price: "138.00", sale: "直降180", type: 1 },
            { id: 2, pic: require("../imgs/index/wrap/t2.jpg"), title: "爱情密码·13枝红玫瑰纯美花束", price: "178.00", sale: "直降220", type: 2 },
            { id: 3, pic: require("../imgs/index/wrap/t3.jpg"), title: "今生与你相伴·9枝红玫瑰韩式花束", price: "138.00", sale: "直降180" },
            { id: 4, pic: require("../imgs/index/wrap/t4.jpg"), title: "一心一意·11枝红玫瑰韩式花束", price: "158.00", sale: "直降150" },
        ]
    }
]
const navData = [
    { id: 1, name: "鲜花用途", list: ["爱情鲜花", "生日鲜花", "友情鲜花", "周年纪念", "婚庆鲜花", "祝贺鲜花"] },
    { id: 2, name: "鲜花花材", list: ["满天星", "玫瑰花", "康乃馨", "百合花", "向日葵", "紫罗兰"] },
    { id: 3, name: "鲜花类别", list: ["日常花束", "创意花盒", "韩式花束", "手提花篮", "开业花篮", "会议桌花"] },
    { id: 4, name: "价格筛选", list: ["150元以内", "150-199", "200-249元", "250-399元", "400-499元", "500-599元", "600-699元", "700元以上"] },
]
const picDate = [
    {
        id: 1, name: "爱情鲜花", descp: "送·让你怦然心动的人", img: require("../imgs/index/love/a1.png"),
        priceList: ["150元以内", "150-199", "200-249元", "250-399元", "400-499元", "500-599元", "600-699元", "700元以上", "查看更多>"],
        flowerList: [
            { id: 11, pic: require("../imgs/index/love/b1.jpg"), title: "携手未来·11枝香槟玫瑰纯美花束", price: "138.00", sale: "328.00", num: "已售 1707" },
            { id: 12, pic: require("../imgs/index/love/b2.jpg"), title: "把心交给我·19枝红玫瑰纯美花束", price: "198.00", sale: "438.00", num: "已售 1202", type: 2 },
            { id: 13, pic: require("../imgs/index/love/b3.jpg"), title: "撩动我的心·33枝粉玫瑰纯美花束", price: "358.00", sale: "518.00", num: "已售 847" },
            { id: 14, pic: require("../imgs/index/love/b4.jpg"), title: "爱你久久·99枝红玫瑰纯美花束", price: "558.00", sale: "808.00", num: "已售 1403", type: 2 },
            { id: 15, pic: require("../imgs/index/love/b5.jpg"), title: "因你而幸福·9枝戴安娜粉玫瑰韩式花束", price: "138.00", sale: "288.00", num: "已售 1122" },
            { id: 16, pic: require("../imgs/index/love/b6.jpg"), title: "为你倾心·11枝红玫瑰韩式花", price: "138.00", sale: "308.00", num: "已售 407", type: 3 },
            { id: 17, pic: require("../imgs/index/love/b7.jpg"), title: "真心喜欢你·19枝粉玫瑰韩式花束", price: "248.00", sale: "388.00", num: "已售 490" },
            { id: 18, pic: require("../imgs/index/love/b8.jpg"), title: "心动时刻·19枝红玫瑰韩式花束", price: "248.00", sale: "488.00", num: "已售 392" },
        ]
    },
    {
        id: 2, name: "大牌轻奢", descp: "礼·大牌轻奢送爱的人", img: require("../imgs/index/love/a2.jpg"),
        priceList: ["150元以内", "150-199", "200-249元", "250-399元", "400-499元", "500-599元", "600-699元", "700元以上", "查看更多>"],
        flowerList: [
            { id: 21, pic: require("../imgs/index/love/c1.jpg"), title: "携手未来·11枝香槟玫瑰纯美花束", price: "138.00", sale: "328.00", num: "已售 1707" },
            { id: 22, pic: require("../imgs/index/love/c2.jpg"), title: "把心交给我·19枝红玫瑰纯美花束", price: "198.00", sale: "438.00", num: "已售 1202", type: 2 },
            { id: 23, pic: require("../imgs/index/love/c3.jpg"), title: "撩动我的心·33枝粉玫瑰纯美花束", price: "358.00", sale: "518.00", num: "已售 847" },
            { id: 24, pic: require("../imgs/index/love/c4.jpg"), title: "爱你久久·99枝红玫瑰纯美花束", price: "558.00", sale: "808.00", num: "已售 1403", type: 2 },
            { id: 25, pic: require("../imgs/index/love/c5.jpg"), title: "因你而幸福·9枝戴安娜粉玫瑰韩式花束", price: "138.00", sale: "288.00", num: "已售 1122" },
            { id: 26, pic: require("../imgs/index/love/c6.jpg"), title: "为你倾心·11枝红玫瑰韩式花", price: "138.00", sale: "308.00", num: "已售 407", type: 3 },
            { id: 27, pic: require("../imgs/index/love/c7.jpg"), title: "真心喜欢你·19枝粉玫瑰韩式花束", price: "248.00", sale: "388.00", num: "已售 490" },
            { id: 28, pic: require("../imgs/index/love/c8.jpg"), title: "心动时刻·19枝红玫瑰韩式花束", price: "248.00", sale: "488.00", num: "已售 392" },
        ]
    },
    {
        id: 3, name: "创意花盒", descp: "赠·朋友/老板/上司", img: require("../imgs/index/love/a3.jpg"),
        priceList: ["150元以内", "150-199", "200-249元", "250-399元", "400-499元", "500-599元", "600-699元", "700元以上", "查看更多>"],
        flowerList: [
            { id: 31, pic: require("../imgs/index/love/d1.jpg"), title: "携手未来·11枝香槟玫瑰纯美花束", price: "138.00", sale: "328.00", num: "已售 1707", type: 4 },
            { id: 32, pic: require("../imgs/index/love/d2.jpg"), title: "把心交给我·19枝红玫瑰纯美花束", price: "198.00", sale: "438.00", num: "已售 1202", type: 3 },
            { id: 33, pic: require("../imgs/index/love/d3.jpg"), title: "撩动我的心·33枝粉玫瑰纯美花束", price: "358.00", sale: "518.00", num: "已售 847" },
            { id: 34, pic: require("../imgs/index/love/d4.jpg"), title: "爱你久久·99枝红玫瑰纯美花束", price: "558.00", sale: "808.00", num: "已售 1403" },
            { id: 35, pic: require("../imgs/index/love/d5.jpg"), title: "因你而幸福·9枝戴安娜粉玫瑰韩式花束", price: "138.00", sale: "288.00", num: "已售 1122" },
            { id: 36, pic: require("../imgs/index/love/d6.jpg"), title: "为你倾心·11枝红玫瑰韩式花", price: "138.00", sale: "308.00", num: "已售 407" },
            { id: 37, pic: require("../imgs/index/love/d7.jpg"), title: "真心喜欢你·19枝粉玫瑰韩式花束", price: "248.00", sale: "388.00", num: "已售 490" },
            { id: 38, pic: require("../imgs/index/love/d8.jpg"), title: "心动时刻·19枝红玫瑰韩式花束", price: "248.00", sale: "488.00", num: "已售 392" },
        ]
    },
    {
        id: 4, name: "送长辈鲜花", descp: "赠·父母/恩师/长辈", img: require("../imgs/index/love/a4.png"),
        priceList: ["150元以内", "150-199", "200-249元", "250-399元", "400-499元", "500-599元", "600-699元", "700元以上", "查看更多>"],
        flowerList: [
            { id: 41, pic: require("../imgs/index/love/e1.jpg"), title: "携手未来·11枝香槟玫瑰纯美花束", price: "138.00", sale: "328.00", num: "已售 1707" },
            { id: 42, pic: require("../imgs/index/love/e2.jpg"), title: "把心交给我·19枝红玫瑰纯美花束", price: "198.00", sale: "438.00", num: "已售 1202" },
            { id: 43, pic: require("../imgs/index/love/e3.jpg"), title: "撩动我的心·33枝粉玫瑰纯美花束", price: "358.00", sale: "518.00", num: "已售 847", type: 2 },
            { id: 44, pic: require("../imgs/index/love/e4.jpg"), title: "爱你久久·99枝红玫瑰纯美花束", price: "558.00", sale: "808.00", num: "已售 1403" },
            { id: 45, pic: require("../imgs/index/love/e5.jpg"), title: "因你而幸福·9枝戴安娜粉玫瑰韩式花束", price: "138.00", sale: "288.00", num: "已售 1122" },
            { id: 46, pic: require("../imgs/index/love/e6.jpg"), title: "为你倾心·11枝红玫瑰韩式花", price: "138.00", sale: "308.00", num: "已售 407" },
            { id: 47, pic: require("../imgs/index/love/e7.jpg"), title: "真心喜欢你·19枝粉玫瑰韩式花束", price: "248.00", sale: "388.00", num: "已售 490" },
            { id: 48, pic: require("../imgs/index/love/e8.jpg"), title: "心动时刻·19枝红玫瑰韩式花束", price: "248.00", sale: "488.00", num: "已售 392" },
        ]
    },
    {
        id: 5, name: "商务鲜花", descp: "给她·美好的礼物", img: require("../imgs/index/love/a5.jpg"),
        priceList: ["150元以内", "150-199", "200-249元", "250-399元", "400-499元", "500-599元", "600-699元", "700元以上", "查看更多>"],
        flowerList: [
            { id: 51, pic: require("../imgs/index/love/f1.jpg"), title: "携手未来·11枝香槟玫瑰纯美花束", price: "138.00", sale: "328.00", num: "已售 1707" },
            { id: 52, pic: require("../imgs/index/love/f2.jpg"), title: "把心交给我·19枝红玫瑰纯美花束", price: "198.00", sale: "438.00", num: "已售 1202", type: 4 },
            { id: 53, pic: require("../imgs/index/love/f3.jpg"), title: "撩动我的心·33枝粉玫瑰纯美花束", price: "358.00", sale: "518.00", num: "已售 847" },
            { id: 54, pic: require("../imgs/index/love/f4.jpg"), title: "爱你久久·99枝红玫瑰纯美花束", price: "558.00", sale: "808.00", num: "已售 1403", type: 3 },
            { id: 55, pic: require("../imgs/index/love/f5.jpg"), title: "因你而幸福·9枝戴安娜粉玫瑰韩式花束", price: "138.00", sale: "288.00", num: "已售 1122" },
            { id: 56, pic: require("../imgs/index/love/f6.jpg"), title: "为你倾心·11枝红玫瑰韩式花", price: "138.00", sale: "308.00", num: "已售 407" },
            { id: 57, pic: require("../imgs/index/love/f7.jpg"), title: "真心喜欢你·19枝粉玫瑰韩式花束", price: "248.00", sale: "388.00", num: "已售 490" },
            { id: 58, pic: require("../imgs/index/love/f8.jpg"), title: "心动时刻·19枝红玫瑰韩式花束", price: "248.00", sale: "488.00", num: "已售 392" },
        ]
    },
    {
        id: 6, name: "永生花", descp: "给她·美好的礼物", img: require("../imgs/index/love/a6.png"),
        priceList: ["150元以内", "150-199", "200-249元", "250-399元", "400-499元", "500-599元", "600-699元", "700元以上", "查看更多>"],
        flowerList: [
            { id: 61, pic: require("../imgs/index/love/g1.png"), title: "携手未来·11枝香槟玫瑰纯美花束", price: "138.00", sale: "328.00", num: "已售 1707" },
            { id: 62, pic: require("../imgs/index/love/g2.png"), title: "把心交给我·19枝红玫瑰纯美花束", price: "198.00", sale: "438.00", num: "已售 1202" },
            { id: 63, pic: require("../imgs/index/love/g3.png"), title: "撩动我的心·33枝粉玫瑰纯美花束", price: "358.00", sale: "518.00", num: "已售 847" },
            { id: 64, pic: require("../imgs/index/love/g4.png"), title: "爱你久久·99枝红玫瑰纯美花束", price: "558.00", sale: "808.00", num: "已售 1403" },
            { id: 65, pic: require("../imgs/index/love/g5.png"), title: "因你而幸福·9枝戴安娜粉玫瑰韩式花束", price: "138.00", sale: "288.00", num: "已售 1122" },
            { id: 66, pic: require("../imgs/index/love/g6.png"), title: "为你倾心·11枝红玫瑰韩式花", price: "138.00", sale: "308.00", num: "已售 407" },
            { id: 67, pic: require("../imgs/index/love/g7.png"), title: "真心喜欢你·19枝粉玫瑰韩式花束", price: "248.00", sale: "388.00", num: "已售 490" },
            { id: 68, pic: require("../imgs/index/love/g8.png"), title: "心动时刻·19枝红玫瑰韩式花束", price: "248.00", sale: "488.00", num: "已售 392" },
        ]
    }
]
const parsentData = [
    {
        id: 7, name: "礼品", descp: "给她·美好的礼物",
        priceList: ["120元以内", "150-199", "200-249元", "250-399元", "400-499元", "500-599元", "600-699元", "700元以上", "查看更多>"],
        ringList: [
            { id: 71, pic: require("../imgs/index/love/h1.png"), title: "携手未来·11枝香槟玫瑰纯美花束", price: "138.00", sale: "328.00", num: "已售 1707" },
            { id: 72, pic: require("../imgs/index/love/h2.png"), title: "把心交给我·19枝红玫瑰纯美花束", price: "198.00", sale: "438.00", num: "已售 1202" },
            { id: 73, pic: require("../imgs/index/love/h3.png"), title: "撩动我的心·33枝粉玫瑰纯美花束", price: "358.00", sale: "518.00", num: "已售 847" },
            { id: 74, pic: require("../imgs/index/love/h4.png"), title: "爱你久久·99枝红玫瑰纯美花束", price: "558.00", sale: "808.00", num: "已售 1403" },
            { id: 75, pic: require("../imgs/index/love/h5.png"), title: "因你而幸福·9枝戴安娜粉玫瑰韩式花束", price: "138.00", sale: "288.00", num: "已售 1122" },
            { id: 76, pic: require("../imgs/index/love/h6.png"), title: "为你倾心·11枝红玫瑰韩式花", price: "138.00", sale: "308.00", num: "已售 407" }
        ]
    }
]
const weekData = [
    {
        id: 8, name: "每周一花", descp: "悦人不如悦己", img: require("../imgs/index/love/a7.png"), more: "查看更多>",
        flowerList: [
            { id: 81, pic: require("../imgs/index/love/i1.jpg"), title: "携手未来·11枝香槟玫瑰纯美花束", price: "138.00", sale: "328.00", num: "已售 1707" },
            { id: 82, pic: require("../imgs/index/love/i2.jpg"), title: "把心交给我·19枝红玫瑰纯美花束", price: "198.00", sale: "438.00", num: "已售 1202" },
            { id: 83, pic: require("../imgs/index/love/i3.jpg"), title: "撩动我的心·33枝粉玫瑰纯美花束", price: "358.00", sale: "518.00", num: "已售 847" },
            { id: 84, pic: require("../imgs/index/love/i4.jpg"), title: "爱你久久·99枝红玫瑰纯美花束", price: "558.00", sale: "808.00", num: "已售 1403" }
        ]
    },
]
export { headData, wrapData, navData, picDate, parsentData, weekData }